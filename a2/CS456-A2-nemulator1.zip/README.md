# CS456-A2 nEmulator

The network emulator requires Python 3. You can use the emulator either by executing the provided nEmulator script or by running `python3 network_emulator.py` directly. 
Find usage instructions using ./nEmulator -h
